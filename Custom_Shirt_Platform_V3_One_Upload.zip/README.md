# Custom Shirt Platform V3 — One Upload Package

Upload every file and folder in this package to the root of your existing GitHub repository.

Included:
- Customer storefront
- Product catalog and categories
- Front, back, and left-chest designer
- Artwork upload and custom text
- Drag, resize, rotate, opacity, duplicate, delete
- Undo and redo
- Adult and youth quantities
- Bulk pricing
- Review and approval
- Demo order storage
- Local admin dashboard
- Order status management
- JSON order export
- Progressive Web App installation
- Offline app shell

## Important limitations

This package is a complete working prototype, but these items cannot be safely activated without your own accounts and business information:

- Real Stripe/Apple Pay/Google Pay payments
- Cloud database and file storage
- Customer login accounts
- Transactional email/SMS
- Shipping labels and live carrier prices
- App Store and Google Play publication

GitHub Pages only hosts static files. Real payments and shared orders require a secure backend such as Supabase plus Stripe.

## Upload once

Delete or replace the old files, then upload:
- index.html
- admin.html
- styles.css
- app.js
- admin.js
- manifest.json
- service-worker.js
- README.md
- icons folder

Commit the upload. GitHub Pages will redeploy automatically.
